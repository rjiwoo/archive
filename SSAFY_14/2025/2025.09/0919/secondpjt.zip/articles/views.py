from django.shortcuts import render

# Create your views here.
def index(request):
    
    context = {
        'number' : request.GET.get('number'),
    }
    return render(request, 'articles/index.html', context)

def detail(request, article_num):
    context = {
        'num' : article_num
    }
    return render(request, 'articles/detail.html', context)