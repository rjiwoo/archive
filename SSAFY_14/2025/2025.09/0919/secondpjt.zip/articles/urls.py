from django.urls import path
from . import views # 현재 폴더와 같이 위치되어 있음

app_name = 'articles'

urlpatterns = [
    path('', views.index, name='index'),    # articles 메인페이지
    path('<int:article_num>/', views.detail, name='detail'),
]
