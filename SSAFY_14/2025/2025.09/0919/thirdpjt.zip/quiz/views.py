import random
from django.shortcuts import render

# Create your views here.
def index(request):
    quizes = [
        ('1+1','2'),
        ('2+2','4'),
        ('3+3','6'),
        ('4+4','8'),
        ('5+5','10'),
        ('6+6','12'),
        ('7+7','14'),
        ('8+8','16'),
        ('9+9','18'),
        ('10+10','20'),
    ]
    picked = random.choice(quizes)
    
    context = {
        'picked': picked[0],
        'picked_answer': picked[1]
    }
    return render(request, 'quiz/index.html', context)