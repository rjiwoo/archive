from django.shortcuts import render

# Create your views here.
def index(request):
    
    picked_answer = request.GET.get('picked_answer')
    message = request.GET.get('message')

    context = {
        'message': message,
        'picked_answer':picked_answer
    }
    return render(request, 'answer/index.html', context)